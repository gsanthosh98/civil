<?php
    $host = 'localhost';
    $dbname = 'u258139758_db';
    $username = 'u258139758_admin';
    $password = 'test123';
